package com.badi.camion;


import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.badi.camion.entities.Camion;
import com.badi.camion.repos.CamionRepository;

@SpringBootTest
class CamionApplicationTests {

	@Autowired
	private CamionRepository camionRepository;
	@Test
	public void testCreateCamion() {
	Camion cm = new Camion(null, "T",782.0,new Date());
	camionRepository.save(cm);
	}
	
	
	@Test
	public void testFindCamion()
	{
	Camion cm = camionRepository.findById(1L).get();
	System.out.println(cm);
	}
	@Test
	public void testUpdateCamion()
	{
	Camion cm = camionRepository.findById(1L).get();
	cm.setPrixCamion(1000.0);
	camionRepository.save(cm);
	}
	@Test
	public void testDeleteCamion()
	{
		camionRepository.deleteById(1L);;
		}

		@Test
		public void testListerTousCamions()
		{
		List<Camion> cm = camionRepository.findAll();
		for (Camion c : cm)
		{
		System.out.println(c);
		}
		}

	


}