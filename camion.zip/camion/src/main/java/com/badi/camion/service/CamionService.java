package com.badi.camion.service;

import java.util.List;

import com.badi.camion.entities.Camion;

public interface CamionService {
	Camion saveCamion(Camion c);
	Camion updateCamion(Camion c);
	void deleteCamion(Camion c);
	 void deleteCamionById(Long id);
	 Camion getCamion(Long id);
	List<Camion> getAllCamions();

}
