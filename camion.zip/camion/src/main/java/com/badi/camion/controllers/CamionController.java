package com.badi.camion.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.badi.camion.entities.Camion;
import com.badi.camion.service.CamionService;

@Controller
public class CamionController {
	
	@Autowired
	CamionService camionService;
	@RequestMapping("/showCreate")
	public String showCreate()
	{
	return"createCamion";
	}


	@RequestMapping("/saveCamion")
	public String saveCamion(@ModelAttribute("camion") Camion camion,
	 @RequestParam("date") String date,
	 ModelMap modelMap) throws
	ParseException
	{
	//conversion de la date
	 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	 Date dateFabrication = dateformat.parse(String.valueOf(date));
	 camion.setDateFabrication(dateFabrication);

	Camion saveCamion = camionService.saveCamion(camion);
	String msg ="camion enregistré avec Id "+saveCamion.getIdCamion();
	modelMap.addAttribute("msg", msg);
	return"createCamion";
	}
	
	
	@RequestMapping("/listeCamion")
	public String listeCamions(ModelMap modelMap)
	{
	List<Camion> cm = camionService.getAllCamions();
	modelMap.addAttribute("camion", cm);
	return "listeCamion";
	}
	
	
	@RequestMapping("/supprimerCamion")
	public String supprimerCamion(@RequestParam("id") Long id,
	 ModelMap modelMap)
	{
	camionService.deleteCamionById(id);
	List<Camion> cm = camionService.getAllCamions();
	modelMap.addAttribute("camion", cm);
	return "listeCamion";
	}
	
	
	@RequestMapping("/modifierCamion")
	public String editerCamion(@RequestParam("id") Long id,ModelMap modelMap)
	{
	Camion c= camionService.getCamion(id);
	modelMap.addAttribute("camion", c);
	return "editeCamion";
	}
	@RequestMapping("/updateCamion")
	public String updateCamion(@ModelAttribute("camion") Camion camion,
	@RequestParam("date") String date,
	ModelMap modelMap) throws ParseException
	{
	//conversion de la date
	 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	 Date dateFabrication = dateformat.parse(String.valueOf(date));
	 camion.setDateFabrication(dateFabrication);

	 camionService.updateCamion(camion);
	 List<Camion> cm = camionService.getAllCamions();
	 modelMap.addAttribute("camion", cm);
	return "listeCamion";
	}

	
	}
	
	
	

