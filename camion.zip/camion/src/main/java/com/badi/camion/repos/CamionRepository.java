package com.badi.camion.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.badi.camion.entities.Camion;

public interface CamionRepository extends JpaRepository<Camion, Long> {

}
