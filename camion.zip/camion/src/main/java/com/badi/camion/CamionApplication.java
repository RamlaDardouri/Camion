package com.badi.camion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamionApplication.class, args);
	}

}
