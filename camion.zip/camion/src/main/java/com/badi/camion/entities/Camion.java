package com.badi.camion.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Camion {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Long idCamion;
	private String modelCamion;
	private Double prixCamion;
	private Date dateFabrication;
	
	
	
	public Camion() {
		super();
	}
	
	
	
	public Camion(Long idCamion, String modelCamion, Double prixCamion, Date dateFabrication) {
		super();
		this.idCamion = idCamion;
		this.modelCamion = modelCamion;
		this.prixCamion = prixCamion;
		this.dateFabrication = dateFabrication;
	}
	public Long getIdCamion() {
		return idCamion;
	}
	public void setIdCamion(Long idCamion) {
		this.idCamion = idCamion;
	}
	public String getModelCamion() {
		return modelCamion;
	}
	public void setModelCamion(String modelCamion) {
		this.modelCamion = modelCamion;
	}
	public Double getPrixCamion() {
		return prixCamion;
	}
	public void setPrixCamion(Double prixCamion) {
		this.prixCamion = prixCamion;
	}
	public Date getDateFabrication() {
		return dateFabrication;
	}
	public void setDateFabrication(Date dateFabrication) {
		this.dateFabrication = dateFabrication;
	}



	@Override
	public String toString() {
		return "Camion [idCamion=" + idCamion + ", modelCamion=" + modelCamion + ", prixCamion=" + prixCamion
				+ ", dateFabrication=" + dateFabrication + "]";
	}
	
	
	
	
	
	
	
	
}
